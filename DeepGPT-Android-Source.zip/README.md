# DeepGPT Android starter

这是 DeepGPT 的第一版原生 Android 项目骨架，使用 Kotlin + Jetpack Compose，界面采用简洁的 ChatGPT 风格，并通过 DeepSeek API 进行对话。

## 当前包含
- 原生 Android / Jetpack Compose 首页与聊天气泡
- 侧边栏、新建对话入口、API Key 设置对话框
- DeepSeek Chat Completions 非流式请求
- API Key 使用 Android Keystore AES-GCM 加密后保存在本机

## 构建
1. 使用 Android Studio 打开此项目目录。
2. 安装 Android SDK 35，并使用 JDK 17。
3. 等待 Gradle 同步完成。
4. 选择 Build > Build Bundle(s) / APK(s) > Build APK(s)。

## 配置 API Key
在应用左侧菜单打开“设置 / API Key”，输入你自己从 DeepSeek 开放平台申请的 API Key。

## 重要说明
- 此版本是可继续开发的 MVP 起点，不是最终成品。
- 当前历史对话仅保存在运行时内存，关闭应用后不会保留；后续阶段会加入 Room 数据库。
- 当前使用普通非流式请求；后续可加入真正的流式输出、停止生成、Markdown/代码高亮和错误重试。
- 不要把 API Key 提交到 Git 仓库或分享给别人。若要公开发布应用，建议通过自有后端代理 API 请求，避免把个人密钥交给所有安装者。
- DeepSeek API 的模型名称、端点和计费规则可能变化，正式发布前请核对官方文档。

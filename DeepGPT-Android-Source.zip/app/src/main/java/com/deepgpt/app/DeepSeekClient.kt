package com.deepgpt.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class DeepSeekClient(private val apiKey: String) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build()

    suspend fun chat(history: List<ChatMessage>): String = withContext(Dispatchers.IO) {
        try {
            val msgs = JSONArray()
            history.forEach {
                msgs.put(JSONObject().put("role", if (it.fromUser) "user" else "assistant").put("content", it.text))
            }
            val payload = JSONObject()
                .put("model", "deepseek-chat")
                .put("messages", msgs)
                .put("stream", false)
            val body = payload.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url("https://api.deepseek.com/chat/completions")
                .addHeader("Authorization", "Bearer $apiKey")
                .addHeader("Content-Type", "application/json")
                .post(body)
                .build()
            client.newCall(request).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val detail = try { JSONObject(raw).optString("error", raw) } catch (_: Exception) { raw }
                    "请求失败（HTTP ${response.code}）：$detail"
                } else {
                    JSONObject(raw).getJSONArray("choices")
                        .getJSONObject(0).getJSONObject("message").getString("content")
                }
            }
        } catch (e: Exception) {
            "连接失败：${e.message ?: "未知错误"}"
        }
    }
}

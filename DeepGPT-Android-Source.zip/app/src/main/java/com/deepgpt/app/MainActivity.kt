package com.deepgpt.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

data class ChatMessage(val text: String, val fromUser: Boolean)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val securePrefs = SecurePrefs(this)
        setContent { DeepGptApp(securePrefs) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeepGptApp(prefs: SecurePrefs) {
    val messages = remember { mutableStateListOf<ChatMessage>() }
    var input by remember { mutableStateOf("") }
    var apiKey by remember { mutableStateOf(prefs.getApiKey()) }
    var showSettings by remember { mutableStateOf(false) }
    var keyDraft by remember { mutableStateOf(apiKey) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val snackbar = remember { SnackbarHostState() }

    MaterialTheme(
        colorScheme = lightColorScheme(
            background = Color(0xFFFFFFFF),
            surface = Color(0xFFFFFFFF),
            primary = Color(0xFF202123),
            onSurface = Color(0xFF202123)
        )
    ) {
        ModalNavigationDrawer(
            drawerState = drawerState,
            drawerContent = {
                ModalDrawerSheet(
                    modifier = Modifier.width(300.dp),
                    drawerContainerColor = Color(0xFFF7F7F8)
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(18.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("DeepGPT", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        IconButton(onClick = { messages.clear(); scope.launch { drawerState.close() } }) {
                            Icon(Icons.Default.Add, contentDescription = "新建对话")
                        }
                    }
                    Text("最近", Modifier.padding(horizontal = 18.dp, vertical = 8.dp), color = Color.Gray)
                    Text(
                        if (messages.isEmpty()) "还没有聊天记录" else "当前对话",
                        Modifier.fillMaxWidth().clickable { scope.launch { drawerState.close() } }.padding(18.dp)
                    )
                    Spacer(Modifier.weight(1f))
                    NavigationDrawerItem(
                        label = { Text("设置 / API Key") },
                        selected = false,
                        onClick = { keyDraft = apiKey; showSettings = true; scope.launch { drawerState.close() } },
                        icon = { Icon(Icons.Default.Settings, contentDescription = null) },
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }
        ) {
            Scaffold(
                snackbarHost = { SnackbarHost(snackbar) },
                topBar = {
                    TopAppBar(
                        title = { Text("DeepGPT", fontWeight = FontWeight.SemiBold) },
                        navigationIcon = {
                            IconButton(onClick = { scope.launch { drawerState.open() } }) {
                                Icon(Icons.Default.Menu, contentDescription = "菜单")
                            }
                        },
                        actions = {
                            IconButton(onClick = { messages.clear() }) {
                                Icon(Icons.Default.Add, contentDescription = "新建对话")
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
                    )
                },
                bottomBar = {
                    Surface(shadowElevation = 5.dp, color = Color.White) {
                        Row(
                            Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.Bottom
                        ) {
                            OutlinedTextField(
                                value = input,
                                onValueChange = { input = it },
                                modifier = Modifier.weight(1f),
                                placeholder = { Text("向 DeepGPT 发送消息") },
                                shape = RoundedCornerShape(26.dp),
                                maxLines = 5
                            )
                            Spacer(Modifier.width(8.dp))
                            FilledIconButton(
                                onClick = {
                                    val prompt = input.trim()
                                    if (prompt.isNotEmpty() && !busy) {
                                        messages.add(ChatMessage(prompt, true))
                                        input = ""
                                        if (apiKey.isBlank()) {
                                            scope.launch { snackbar.showSnackbar("请先在侧边栏设置 DeepSeek API Key") }
                                        } else {
                                            busy = true
                                            messages.add(ChatMessage("正在思考…", false))
                                            scope.launch {
                                                val answer = DeepSeekClient(apiKey).chat(messages.dropLast(1).dropLast(1))
                                                messages.removeAt(messages.lastIndex)
                                                messages.add(ChatMessage(answer, false))
                                                busy = false
                                            }
                                        }
                                    }
                                },
                                enabled = input.isNotBlank() && !busy,
                                modifier = Modifier.size(48.dp)
                            ) { Icon(Icons.Default.Send, contentDescription = "发送") }
                        }
                    }
                },
                containerColor = Color.White
            ) { padding ->
                if (messages.isEmpty()) {
                    Column(
                        Modifier.fillMaxSize().padding(padding).padding(24.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("有什么可以帮忙的？", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(12.dp))
                        Text("由 DeepSeek 提供 AI 能力", color = Color.Gray)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize().padding(padding),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 20.dp),
                        verticalArrangement = Arrangement.spacedBy(18.dp)
                    ) {
                        items(messages) { msg ->
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = if (msg.fromUser) Arrangement.End else Arrangement.Start
                            ) {
                                Surface(
                                    color = if (msg.fromUser) Color(0xFFF4F4F4) else Color.White,
                                    shape = RoundedCornerShape(18.dp),
                                    modifier = Modifier.widthIn(max = 320.dp)
                                ) {
                                    Text(msg.text, Modifier.padding(horizontal = 16.dp, vertical = 12.dp), color = Color(0xFF202123))
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showSettings) {
        AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text("DeepSeek API 设置") },
            text = {
                Column {
                    Text("输入你在 DeepSeek 开放平台创建的 API Key。请勿把密钥发给他人。")
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = keyDraft,
                        onValueChange = { keyDraft = it },
                        label = { Text("API Key") },
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    apiKey = keyDraft.trim()
                    prefs.saveApiKey(apiKey)
                    showSettings = false
                }) { Text("保存") }
            },
            dismissButton = { TextButton(onClick = { showSettings = false }) { Text("取消") } }
        )
    }
}
